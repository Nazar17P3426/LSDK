LSDK.exe By Mazeicon

---------------------------

My First Malware

rate damage : destructive